// export let apiKey = "adnasdoasflak1";
export default "adnasdoasflak1";
export let apiKey = "adnasdoasflak1";
export let abc = "abc";
